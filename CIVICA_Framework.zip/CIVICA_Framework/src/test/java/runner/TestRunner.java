package runner;

import org.junit.runner.RunWith;
import org.testng.annotations.Listeners;

import io.cucumber.junit.Cucumber;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;

@RunWith(Cucumber.class)
@CucumberOptions(features="src/test/java/features", 
plugin = { "pretty",
"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:" },
glue="testcases_stepdef",
dryRun = false
,tags = "@Login_One"
)  
        
@Listeners({ExtentITestListenerClassAdapter.class})
public class TestRunner extends AbstractTestNGCucumberTests{
    
    
}
