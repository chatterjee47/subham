package testcases_stepdef;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import BaseClass.baseUtils;
import BaseClass.browsersetup;
import PageObjectory.Login_OnePage;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import junit.framework.Assert;



public class Login_OneTest extends baseUtils {
	
	
	Login_OnePage login;
	
	static Properties prop;
	static FileInputStream fileInput;
	static File file = new File(System.getProperty("user.dir") + "\\config\\file.properties");


	@Before
	public void ConfigurationSetup(){
	try {
	fileInput = new FileInputStream(file);
	} catch (FileNotFoundException e) {
	e.printStackTrace();
	}
	prop = new Properties();
	try {
	prop.load(fileInput);
	} catch (IOException e) {
	e.printStackTrace();
	}
	}
	

	
	@Given("User Logged in to nextmalinko")
	public void user_logged_in_to_nextmalinko() throws InterruptedException {
		ConfigurationSetup();
		driver = browsersetup.setup(prop.getProperty("Browsername"), prop.getProperty("malinkoUrl"));
		Thread.sleep(3000);	
	}
	
	@When("User type in Username {string}")
	public void user_type_in_username(String username) throws InterruptedException {
		login= new Login_OnePage(driver);
		login.setUsername(username);
		Thread.sleep(1000);
	}
	
	@When("User type Password {string}")
	public void user_type_password(String password) throws InterruptedException {
		login.setPassword(password);
		Thread.sleep(2000);
	}
	
	
	
	
	@Given("^I am on the homepage and I click on Login tab$")
	public void i_am_on_the_homepage_and_I_click_on_Login_tab() throws Throwable {
		ConfigurationSetup();
		driver = browsersetup.setup(prop.getProperty("Browsername"), prop.getProperty("malinkoUrl"));
		Thread.sleep(3000);		
	}
	
	@Given("^User close the browser after execution$")
	public void User_close_the_browser_after_execution() throws Throwable {
		driver.close();
		Thread.sleep(3000);		
	}
	
    @When("^I type in Username \"([^\"]*)\"$")
    public void i_type_in_username_something(String username) throws Throwable {
        login= new Login_OnePage(driver);
		login.setUsername(username);
		Thread.sleep(1000);
    }

    @When("I verify error message {string}")
    public void i_verify_error_message(String ErrorMsg) throws InterruptedException {
       String errMsg= login.validateErrmsg();
       System.out.println(errMsg);
       Thread.sleep(1000);
       if(errMsg.equals(ErrorMsg)) {
    	   System.out.println("Passed");
       }
       Assert.assertEquals(errMsg, ErrorMsg);
       Thread.sleep(1000);
    }


 
	@When("^I type Password \"([^\"]*)\"$")
	public void i_type_password(String password) throws Throwable {
		login.setPassword(password);
		Thread.sleep(2000);
	}

	
	
	@When("^I click Login button and nothing should happen$")
	public void i_click_Login_button_and_nothing_should_happen() throws Throwable {
		login.ClickOnLoginButton();
		Thread.sleep(5000);
	}


}
