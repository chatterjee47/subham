package Utilities;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TodaysDate {

	public static void main(String[] args) throws ParseException {
		DateFormat dateFormat = new SimpleDateFormat("dd");
		Date date = new Date();
		String datetoday= dateFormat.format(date);
		System.out.println(datetoday);

	}

}
