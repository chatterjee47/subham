package Utilities;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.util.Assert;

import BaseClass.baseUtils;

public class util extends baseUtils{

	public util(WebDriver driver) {
		baseUtils.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void ScrollToBottom() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,350)", "");
	}

	public void SelectDropdownByText(WebElement element, String value) {
		Select userroledropdown = new Select(element);
		userroledropdown.selectByVisibleText(value);
		System.out.println("Text from dropdown selected successfully");
	}

	public void SelectDropdownByValue(WebElement element, String value) {
		Select userroledropdown = new Select(element);
		userroledropdown.selectByValue(value);
		System.out.println("Value from dropdown selected successfully");
	}

	public void pause(Integer milliseconds) {
		try {
			TimeUnit.MILLISECONDS.sleep(milliseconds);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	
	public void saveUserDetails(String value,WebElement TextName) {
		 String UserDetails= TextName.getText();
		 File f = new File(value);
	      try{
	         FileUtils.writeStringToFile(f, UserDetails, Charset.defaultCharset());
	      }catch(IOException exc){
	         exc.printStackTrace();
	      }
	}
	
	
	public void saveText(String value) {
		 String currenturl = driver.getCurrentUrl();
		 File f = new File(value);
	      try{
	         FileUtils.writeStringToFile(f, currenturl, Charset.defaultCharset());
	      }catch(IOException exc){
	         exc.printStackTrace();
	      }
	}
	
	
	public void TodayDatepicker(List<WebElement> element) {
		DateFormat dateFormat = new SimpleDateFormat("dd");
		Date todaydate = new Date();
		String today = dateFormat.format(todaydate);

		List<WebElement> columns = element;
		for (WebElement cell : columns) {
		//	System.out.println("Cell display as : " + cell.getText());
			if (cell.getText().equals(today)) {
				cell.click();
				break;
			}
		}
	}

	

	public void datepicker(List<WebElement> element) {
		/*DateFormat dateFormat = new SimpleDateFormat("d");
		Date todaydate = new Date();
		String today = dateFormat.format(todaydate);*/

		List<WebElement> columns = element;
		for (WebElement cell : columns) {
			System.out.println("Cell display as : " + cell.getText());
			if (cell.getText().equals("1")) {
				cell.click();
				break;
			}
		}
	}

	
	
	public void CaptureText(List<WebElement> Table, String value) {

		List<WebElement> col = Table;
		int count = col.size();

		for (int i = 0; i < count; i++) {
			String data = col.get(i).getText();
			if (data.equals(value)) {
				System.out.println("Data displayed as : "+data);
			}else {
				System.out.println("No Data displayed");
			}
		}
	}
	
	public void scrolltoview(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver; 
		js.executeScript("arguments[0].scrollIntoView(true);", element);
	}
	public void NameDisplayed(List<WebElement> Table, String value) {

		List<WebElement> col = Table;
		int count = col.size();

		for (int i = 0; i < count; i++) {
			String data = col.get(i).getText();
			if (data.equals(value)) {
				System.out.println("Staff name present is " + value);
				col.get(i).click();
				break;
			}
		}
	}
}
