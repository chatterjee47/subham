package PageObjectory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseClass.baseUtils;

public class Login_OnePage extends baseUtils {

	public Login_OnePage(WebDriver driver) {
		baseUtils.driver = driver;
		PageFactory.initElements(driver, this);
	}

	/*
	@FindBy(xpath = "//a[@id='loginLink']")
	private WebElement loginLink;
	
	public void loginLink() {
		loginLink.click();
	}
	
	@FindBy(xpath = "//input[@value='Log in']")
	private WebElement logInBtn;
	
	public void logInBtn() {
		logInBtn.click();
	}
*/
	
	//@FindBy(xpath = "//h4[contains(text(),'Login Portal')]")
	//private WebElement LoginPortallink;

    @FindBy(xpath = "//input[@type = 'text' and @name = 'user[email]' and @id = 'user_email']")
	private WebElement UsernameText; // email input
	
	//private WebElement UsernameText = driver.findElement(By.cssSelector("input#user_email"));

	//private WebElement PasswordText = driver.findElement(By.cssSelector("input#user_password"));
	
	@FindBy(xpath = "//input[@type = 'password' and @name = 'user[password]' and @id = 'user_password']")
	private WebElement PasswordText; // password input
	
	@FindBy(xpath = "//input[@name='commit']")
	private WebElement LoginButton;	
	
	@FindBy(xpath = "//body[1]/div[1]/div[4]/div[1]/div[1]/span[1]")
	private WebElement ErrorMsg;
	
public String validateErrmsg() {
	return ErrorMsg.getText();
	}
	
	
	public void setUsername(String username) {
		
		UsernameText.click();
		UsernameText.sendKeys(username);
	}
	
	public void setPassword(String password) {
		PasswordText.click();
		PasswordText.sendKeys(password);
	}
	
	public void ClickOnLoginButton() {
		LoginButton.click();
	}
	
	
	
}
